
import java.net.DatagramSocket;
import java.net.Socket;

/*
 * An abstract client, ust for further development usage.
 */
public abstract class AbstractClient implements Client {

    boolean alive = false;

}
