package client;

import java.net.DatagramSocket;
import java.net.Socket;

public abstract class AbstractClient implements Client {

    boolean alive = false;

}
