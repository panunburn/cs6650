# Project Submissions Guidelines
##Weiran Guo

## Usage
This project is built upon intellij, we first need to launch the ServerApp, then the Client App.

we need to configure the commandline arguments,
for server, we need two arguments: port number and protocol type.

For client, we need three argumesnts: ip address, port number, and protocol type.

So we need to create total 4 applications, two server and two clients.

The TCP Server and client can communicate with each other perfectly, and the KV store performs well.
The UDP Server and client might has some data loss during transmission.
