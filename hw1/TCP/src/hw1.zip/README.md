# cs6650 HW1
Weiran Guo

Usage:
javac Server.java
javac Client.java

java Server
java Client 127.0.0.1 32000

