public enum Action {
    PUT,
    DELETE
}
